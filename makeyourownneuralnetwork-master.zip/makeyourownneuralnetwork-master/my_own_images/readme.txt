These files are PNG images of size 28 x 28

The file name pattern is 2828_my_own_....N_.png where N is the actual label (eg 3) and the ... can be any short text
